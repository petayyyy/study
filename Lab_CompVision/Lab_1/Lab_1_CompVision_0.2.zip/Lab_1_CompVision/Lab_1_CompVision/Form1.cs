namespace Lab_1_CompVision
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            pictureBox1.Image = new Bitmap(400, 400);
            dataGridView1.ColumnCount = 4;
            dataGridView1.RowCount = 1;
            dataGridView1.RowHeadersVisible = false;
            dataGridView1.Columns[0].HeaderText = "#";
            dataGridView1.Columns[0].Width = 50;
            dataGridView1.Columns[1].HeaderText = "X";
            dataGridView1.Columns[1].Width = 100;
            dataGridView1.Columns[2].HeaderText = "Y";
            dataGridView1.Columns[2].Width = 100;
            dataGridView1.Columns[3].HeaderText = "Z";
            dataGridView1.Columns[3].Width = 100;
            dataGridView1.Width = 350;

        }
        public void OpenCSV(string csvPath)
        {
            string csvContentStr = File.ReadAllText(csvPath);
            string[] vs = csvContentStr.Split('\n');
            string[] vs2;
            for (int i = 1; i < vs.Length-1; i++)
            {
                vs2 = vs[i].Split(';');
                dataGridView1.RowCount += 1;
                dataGridView1.Rows[i-1].Cells[0].Value = Int32.Parse(vs2[0]);
                dataGridView1.Rows[i-1].Cells[1].Value = Int32.Parse(vs2[1]);
                dataGridView1.Rows[i-1].Cells[2].Value = Int32.Parse(vs2[2]);
                dataGridView1.Rows[i-1].Cells[3].Value = Int32.Parse(vs2[3]);
            }
        }

        public void OpenTXT(string txtPath)
        {
            string txtContentStr = File.ReadAllText(txtPath);
            string[] vs = txtContentStr.Split('\n');
            string[] vs2;
            for (int i = 1; i < vs.Length-1; i++)
            {
                vs2 = vs[i].Split(' ');
                dataGridView1.RowCount += 1;
                dataGridView1.Rows[i - 1].Cells[0].Value = Int32.Parse(vs2[0]);
                dataGridView1.Rows[i - 1].Cells[1].Value = Int32.Parse(vs2[1]);
                dataGridView1.Rows[i - 1].Cells[2].Value = Int32.Parse(vs2[2]);
                dataGridView1.Rows[i - 1].Cells[3].Value = Int32.Parse(vs2[3]);
            }
        }
        public void SaveTXT(string txtPath)
        {
            string data = "# X Y Z\n";
            for (int i = 0; i < dataGridView1.RowCount-1; i++)
            {
                try { data += dataGridView1.Rows[i].Cells[0].Value.ToString() + " "; }
                catch { data += "" + " "; }
                data += dataGridView1.Rows[i].Cells[1].Value.ToString() + " ";
                data += dataGridView1.Rows[i].Cells[2].Value.ToString() + " ";
                data += dataGridView1.Rows[i].Cells[3].Value.ToString();
                data += "\n";
            }
            File.WriteAllText(txtPath, data);
        }
        public void SaveCSV(string csvPath)
        {
            string data = "#;X;Y;Z\n";
            for (int i = 0; i < dataGridView1.RowCount - 1; i++)
            {
                try { data += dataGridView1.Rows[i].Cells[0].Value.ToString() + ";"; }
                catch { data += "" + ";"; }
                data += dataGridView1.Rows[i].Cells[1].Value.ToString() + ";";
                data += dataGridView1.Rows[i].Cells[2].Value.ToString() + ";";
                data += dataGridView1.Rows[i].Cells[3].Value.ToString();
                data += "\n";
            }
            File.WriteAllText(csvPath, data);
        }

        private void Open_but_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult res = openFileDialog1.ShowDialog();
                if (res == DialogResult.OK)
                {
                    if (openFileDialog1.FileName.Contains(".csv")) OpenCSV(openFileDialog1.FileName);
                    else OpenTXT(openFileDialog1.FileName);
                }
                else MessageBox.Show("Error, you don't take any file.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error, your file have incorrect type. You must take .txt or .csv.");
            }
            Start_Claster.Text = "Start show point";
        }

        private void Save_but_Click(object sender, EventArgs e)
        {
            if (dataGridView1.RowCount >= 2)
            {
                try
                {
                    if (fileFormat.Text == "TXT") SaveTXT(@"C:\Users\ilyah\Desktop\ers.txt");
                    else SaveCSV(@"C:\Users\ilyah\Desktop\ers.csv");
                }
                catch
                {
                    MessageBox.Show("First carry out the division into clusters");
                }
            }
        }
        public void drawClaster(int centerX, int centerY, int num, Graphics graphics)
        {
            int radius = 10;
            Pen pen = new Pen(Color.Red);
            Font drawFont = new Font("Arial", 10);
            StringFormat drawFormat = new StringFormat();
            SolidBrush drawBrush = new SolidBrush(Color.Red);
            drawFormat.FormatFlags = StringFormatFlags.DirectionRightToLeft;
            graphics.DrawEllipse(pen, centerX - radius, centerY - radius,
                      radius + radius, radius + radius);
            graphics.DrawString(num.ToString(), drawFont, drawBrush, centerX + radius, centerY - radius, drawFormat);
        }
        public void show_point()
        {
            Graphics graphics = Graphics.FromImage(pictureBox1.Image);
            graphics.FillRectangle(Brushes.White, new Rectangle(0, 0, pictureBox1.Width, pictureBox1.Height));
            for (int i = 0; i < dataGridView1.RowCount-1; i++)
            {
                for (int j = (int)dataGridView1.Rows[i].Cells[1].Value; j < (int)dataGridView1.Rows[i].Cells[1].Value + 3; j++)
                {
                    for (int d = (int)dataGridView1.Rows[i].Cells[2].Value; d < (int)dataGridView1.Rows[i].Cells[2].Value + 3; d++)
                        try
                        {
                            int a = (255 * (int)dataGridView1.Rows[i].Cells[3].Value) / 1023;
                            //((Bitmap)pictureBox1.Image).SetPixel(j, d, Color.FromArgb(0,0,0));
                            ((Bitmap)pictureBox1.Image).SetPixel(j, d, Color.FromArgb(255 - a, 255 - a, 255 - a));
                        }
                        catch { continue; }
                }
            }
        }
        private void Generate_but_Click(object sender, EventArgs e)
        {
            Random rand = new Random();
            dataGridView1.RowCount = 1;
            Graphics graphics = Graphics.FromImage(pictureBox1.Image);
            graphics.FillRectangle(Brushes.White, new Rectangle(0, 0, pictureBox1.Width, pictureBox1.Height));
            for (int i = 0; i < Int32.Parse(Size_data.Text); i++)
            {
                dataGridView1.RowCount += 1;
                dataGridView1.Rows[i].Cells[1].Value = rand.Next(0, 400);
                dataGridView1.Rows[i].Cells[2].Value = rand.Next(0, 400);
                dataGridView1.Rows[i].Cells[3].Value = rand.Next(0, 1023);
            }
            Start_Claster.Text = "Start show point";
            pictureBox1.Refresh();
        }
        int claster_index = 0;
        List<int> Clasters_point_x = new List<int>();
        List<int> Clasters_point_y = new List<int>();
        private void Start_Claster_Click(object sender, EventArgs e)
        {
            if (Start_Claster.Text == "Start show point")
            {
                claster_index = 0;
                Clasters_point_x.Clear();
                Clasters_point_y.Clear();
                show_point();
                Start_Claster.Text = "Start Clastering";
                pictureBox1.Refresh();
            }
            else if (Start_Claster.Text == "Start Clastering")
            {
                bool f = false;
                int q = 0;
                Graphics graphics = Graphics.FromImage(pictureBox1.Image);
                Clasters_point_x.Add((int)dataGridView1.Rows[0].Cells[1].Value);
                Clasters_point_y.Add((int)dataGridView1.Rows[0].Cells[2].Value);
                dataGridView1.Rows[0].Cells[0].Value = claster_index+1;
                drawClaster(Clasters_point_x[0], Clasters_point_y[0], 1, graphics);
                for (int i = 1; i < dataGridView1.RowCount - 1; i++)
                {
                    int x = (int)dataGridView1.Rows[i].Cells[1].Value;
                    int y = (int)dataGridView1.Rows[i].Cells[2].Value;
                    double min = 999;
                    for (int j = 0; j < claster_index+1; j++)
                    {
                        if (Math.Sqrt(Math.Pow(x - Clasters_point_x[j], 2) + Math.Pow(y - Clasters_point_y[j], 2)) <= Int32.Parse(Len_Claster.Text))
                        {
                            f = true;
                            if (Math.Sqrt(Math.Pow(x - Clasters_point_x[j], 2) + Math.Pow(y - Clasters_point_y[j], 2)) < min)
                            {
                                q = j;
                                min = Math.Sqrt(Math.Pow(x - Clasters_point_x[j], 2) + Math.Pow(y - Clasters_point_y[j], 2));
                            }
                        }
                    }
                    if (!f)
                    {
                        claster_index++;
                        Clasters_point_x.Add(x);
                        Clasters_point_y.Add(y);
                        drawClaster(Clasters_point_x[claster_index], Clasters_point_y[claster_index], claster_index + 1, graphics);
                        dataGridView1.Rows[i].Cells[0].Value = claster_index + 1;
                    }
                    else
                    {
                        dataGridView1.Rows[i].Cells[0].Value = q+1;
                        Pen pen = new Pen(Color.Blue);
                        graphics.DrawLine(pen, x, y, Clasters_point_x[q], Clasters_point_y[q]);
                    }
                    f = false;
                    q = 0; 
                }
                pictureBox1.Refresh();
                Start_Claster.Text = "More Clastering";
            }
            else if (Start_Claster.Text == "More Clastering")
            {
                show_point();
                Graphics graphics = Graphics.FromImage(pictureBox1.Image);
                Pen pen = new Pen(Color.Blue);
                bool f = true;
                for (int j = 0; j < claster_index + 1; j++)
                {
                    for (int i = 0; i < dataGridView1.RowCount - 1; i++)
                    {
                        if (j == (int)dataGridView1.Rows[i].Cells[0].Value - 1)
                        {
                            Clasters_point_x[j] = ((int)dataGridView1.Rows[i].Cells[1].Value + Clasters_point_x[j]) / 2;
                            Clasters_point_y[j] = ((int)dataGridView1.Rows[i].Cells[2].Value + Clasters_point_y[j]) / 2;
                        }
                    }
                }
                for (int i = 0; i < dataGridView1.RowCount - 1; i++)
                {
                    double min = 999;
                    int q = 0;
                    for (int j = 0; j < claster_index + 1; j++)
                    {
                        int x = (int)dataGridView1.Rows[i].Cells[1].Value;
                        int y = (int)dataGridView1.Rows[i].Cells[2].Value;
                        if (Math.Sqrt(Math.Pow(x - Clasters_point_x[j], 2) + Math.Pow(y - Clasters_point_y[j], 2)) <= min)
                        {
                            q = j;
                            min = Math.Sqrt(Math.Pow(x - Clasters_point_x[j], 2) + Math.Pow(y - Clasters_point_y[j], 2));
                        }
                    }
                    if ((int)dataGridView1.Rows[i].Cells[0].Value != q + 1 && min != 999)
                    {
                        f = false;
                        dataGridView1.Rows[i].Cells[0].Value = q + 1;
                    }
                    graphics.DrawLine(pen, (int)dataGridView1.Rows[i].Cells[1].Value, (int)dataGridView1.Rows[i].Cells[2].Value, Clasters_point_x[(int)dataGridView1.Rows[i].Cells[0].Value - 1], Clasters_point_y[(int)dataGridView1.Rows[i].Cells[0].Value - 1]);
                }
                for (int j = 0; j < claster_index + 1; j++)
                {
                    drawClaster(Clasters_point_x[j], Clasters_point_y[j], j + 1, graphics);
                }
                pictureBox1.Refresh();
                if (f) Start_Claster.Text = "Clear";
            }
            else if (Start_Claster.Text == "Clear")
            {
                Graphics graphics = Graphics.FromImage(pictureBox1.Image);
                graphics.FillRectangle(Brushes.White, new Rectangle(0, 0, pictureBox1.Width, pictureBox1.Height));
                pictureBox1.Refresh();
            }
        }
    }
}