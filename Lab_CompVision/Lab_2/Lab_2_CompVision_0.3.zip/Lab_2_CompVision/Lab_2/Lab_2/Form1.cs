﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            pictureBox1.Image = new Bitmap(400, 400);
            pictureBox2.Image = new Bitmap(400, 400);
            
        }
        Image work_image = new Bitmap(400, 400);
        private void Open_but_Click(object sender, EventArgs e)
        {
            try
            {
                DialogResult res = openFileDialog1.ShowDialog();
                if (res == DialogResult.OK)
                {
                    work_image = Image.FromFile(openFileDialog1.FileName);
                    pictureBox1.Image = Image.FromFile(openFileDialog1.FileName);

                }
                else MessageBox.Show("Error, you don't take any file.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error, your file have incorrect type. You must take .png, .jpg or .bmp.");
            }
            Start_trafic_but.BackColor = Color.White;
            Graphics graphics2 = Graphics.FromImage(pictureBox2.Image);
            graphics2.FillRectangle(Brushes.Black, new Rectangle(0, 0, pictureBox2.Width, pictureBox2.Height));
            pictureBox1.Refresh();
            pictureBox2.Refresh();
        }
        int[] rectangle = new int[4];
        int[] pix = new int[2];
        Rectangle rect;
        int R = 0; int G = 0; int B = 0;
        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            Graphics graphics = Graphics.FromImage(pictureBox1.Image);
            if (comboBox1.Text == "One pixel")
            {
                pix[0] = e.Location.X;
                pix[1] = e.Location.Y;
                Font drawFont = new Font("Arial", 20);
                StringFormat drawFormat = new StringFormat();
                SolidBrush drawBrush = new SolidBrush(Color.Blue);
                Color pixel = ((Bitmap)work_image).GetPixel(pix[0], pix[1]);
                drawFormat.FormatFlags = StringFormatFlags.DirectionRightToLeft;
                graphics.DrawString(pixel.B.ToString()+", "+ pixel.G.ToString() + ", "+ pixel.R.ToString(), drawFont, drawBrush, e.Location.X, e.Location.Y, drawFormat);
                pictureBox1.Refresh();
            }
            else
            {
                rectangle[0] = e.Location.X;
                rectangle[1] = e.Location.Y;
            }
        }
        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            Graphics graphics = Graphics.FromImage(pictureBox1.Image);
            if (comboBox1.Text != "One pixel")
            {
                rectangle[2] = e.Location.X;
                rectangle[3] = e.Location.Y;

                Pen pen = new Pen(Color.Blue);
                graphics.DrawRectangle(pen, GetRect());
                Font drawFont = new Font("Arial", 20);
                StringFormat drawFormat = new StringFormat();
                SolidBrush drawBrush = new SolidBrush(Color.Blue);
                drawFormat.FormatFlags = StringFormatFlags.DirectionRightToLeft;
                graphics.DrawString(B.ToString() + ", " + G.ToString() + ", " + R.ToString(), drawFont, drawBrush, e.Location.X, e.Location.Y, drawFormat);
                
                pictureBox1.Refresh();
            }
        }
        public Rectangle GetRect(){
            rect = new Rectangle();
            rect.X = Math.Min(rectangle[0], rectangle[2]);
            rect.Y = Math.Min(rectangle[1], rectangle[3]);
            rect.Width = Math.Abs(rectangle[0] - rectangle[2]);
            rect.Height = Math.Abs(rectangle[1] - rectangle[3]);
            sr_RGB(rect.X, rect.Y, rect.Height, rect.Width);
            return rect;
        }
        public void sr_RGB (int x, int y, int w, int h)
        {
            Color pixel = ((Bitmap)work_image).GetPixel(x, y);
            R = pixel.R; G = pixel.G; B = pixel.B;
            int R_minn = 255; int G_minn = 255; int B_minn = 255;
            int R_maxx = 0; int G_maxx = 0; int B_maxx = 0;

            for (int i = x; i < x+h; i++)
            {
                for (int j = y; j < y+w; j++)
                {
                    pixel = ((Bitmap)work_image).GetPixel(i, j);
                    R = (R + pixel.R)/2;
                    G = (G + pixel.G)/2;
                    B = (B + pixel.B)/2;
                    if (R_minn > R) R_minn = R;
                    else if (G_minn > G) G_minn = G;
                    else if (B_minn > B) B_minn = B;
                    else if (R_maxx < R) R_maxx = R;
                    else if (G_maxx < G) G_maxx = G;
                    else if (B_maxx < B) B_maxx = B;
                }
            }
            B_min.Text = R_minn.ToString();
            G_min.Text = G_minn.ToString();
            R_min.Text = B_minn.ToString();
            B_max.Text = R_maxx.ToString();
            G_max.Text = G_maxx.ToString();
            R_max.Text = B_maxx.ToString();
            pictureBox1.Refresh();
        }

        private void Clear_but_Click(object sender, EventArgs e)
        {
            Graphics graphics = Graphics.FromImage(pictureBox1.Image); Graphics graphics2 = Graphics.FromImage(pictureBox2.Image);
            graphics.FillRectangle(Brushes.White, new Rectangle(0, 0, pictureBox1.Width, pictureBox1.Height));
            graphics2.FillRectangle(Brushes.Black, new Rectangle(0, 0, pictureBox2.Width, pictureBox2.Height));
            pictureBox1.Image = Image.FromFile(openFileDialog1.FileName);
            Start_trafic_but.BackColor = Color.White;
            pictureBox1.Refresh();
            pictureBox2.Refresh();
        }
        private void Start_but_Click(object sender, EventArgs e)
        {
            Graphics graphics = Graphics.FromImage(pictureBox2.Image);
            if (Start_but.Text != "Refresh")
            {
                detect_claster(pictureBox2, Int32.Parse(B_min.Text), Int32.Parse(B_max.Text), Int32.Parse(G_min.Text), Int32.Parse(G_max.Text), Int32.Parse(R_min.Text), Int32.Parse(R_max.Text));
                pictureBox2.Refresh();
                Start_but.Text = "Refresh";
            }
            else
            {
                Start_but.Text = "Start find color";
                graphics.FillRectangle(Brushes.Black, new Rectangle(0, 0, pictureBox2.Width, pictureBox2.Height));
                pictureBox2.Refresh();
            }
        }

        public Rectangle detect_claster(PictureBox pictureBox, int R_minn, int R_maxx, int G_minn, int G_maxx, int B_minn, int B_maxx, bool is_detect_claster = false)
        {
            Graphics graphics = Graphics.FromImage(pictureBox1.Image);
         // graphics.FillRectangle(Brushes.Black, new Rectangle(0, 0, pictureBox2.Width, pictureBox2.Height));
            int[,] frame = new int[400, 400];
            Rectangle rectangle = new Rectangle();
            int max_k = 0;
            double max_f = 0;
            for (int i = 0; i < work_image.Height; i++)
            {
                for (int j = 0; j < work_image.Width; j++)
                {
                    Color pixel = ((Bitmap)work_image).GetPixel(i, j);
                    if (pixel.R >= R_minn && pixel.R <= R_maxx && pixel.B >= B_minn && pixel.B <= B_maxx && pixel.G >= G_minn && pixel.G <= G_maxx)
                    {
                        frame[i, j] = 1;
                        ((Bitmap)pictureBox2.Image).SetPixel(i, j, Color.White);
                    }
                }
            }
            pictureBox2.Refresh();
            for (int i = 10; i < work_image.Height; i += 10)
            {
                for (int j = 10; j < work_image.Width; j += 10)
                {
                    
                    int k = 1;
                    bool exit = false;
                    bool last = false;
                    double f;
                    while (!exit)
                    {
                        if (last) f = counttt(frame, i, j, k, true);
                        else f = counttt(frame, i, j, k);
                        if (f < 0.2 && !last) exit = true;
                        else if (f > 0.4)
                        {
                            k++;
                            last = true;
                        }
                        else if (f <= 0.4 && f >= 0.2)
                        {
                            if (k > max_k || (k == max_k && f > max_f)) {
                                max_k = k;
                                max_f = f;
                                rectangle.X = i - 5 * (k - 1);
                                rectangle.Y = j - 5 * (k-1);
                                rectangle.Height = 10 * (k-1);
                                rectangle.Width = 10 * (k-1);
                            }
                            exit = true;
                        }
                    }
                }
            }
            Pen pen = new Pen(Color.Black);
            if (rectangle.Height > 20) graphics.DrawRectangle(pen, rectangle);
            pictureBox2.Refresh();
            pictureBox1.Refresh();
            return rectangle;

        }
        public double counttt(int[,] frame, int i, int j, int h, bool tr = false)
        {
            int[] sum = new int[2] { 0, 0 };
            for (int k_x = i - 5*h; k_x < i + 5*h; k_x++)
            {
                for (int k_y = j - 5*h; k_y < j + 5*h; k_y++)
                {
                    sum[0] += frame[k_x, k_y];
                    sum[1]++;
                }
            }
            pictureBox2.Refresh();
            return (double)sum[0] / sum[1];
        }

        private void Start_trafic_but_Click(object sender, EventArgs e)
        {

            //Graphics graphics = Graphics.FromImage(pictureBox1.Image);
            //Pen pen = new Pen(Color.Black);
            Rectangle rect = detect_claster(pictureBox1, 240, 255, 240, 255, 10, 80);// graphics.DrawRectangle(pen, rect);
            if (rect.Width > 20) Start_trafic_but.BackColor = Color.Yellow;
            // MessageBox.Show(rect.ToString());
            rect = detect_claster(pictureBox1, 122, 225, 230, 255, 180, 255); //graphics.DrawRectangle(pen, rect);
            if (rect.Width > 20) Start_trafic_but.BackColor = Color.Green;
            // MessageBox.Show(rect.ToString());
            rect = detect_claster(pictureBox1, 185, 229, 13, 140, 26, 115);// graphics.DrawRectangle(pen, rect);
            if (rect.Width > 20) Start_trafic_but.BackColor = Color.Red;
            // MessageBox.Show(rect.ToString());
            //pictureBox1.Refresh();
        }
    }
}
