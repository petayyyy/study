﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab3
{
    class Rab
    {
        public struct Data
        {
            private string company;
            private int workers;
            private int num_enroll;
            private int num_dismiss;
            public string Company
            {
                get { return company; }
                set { company = value; }
            }
            public int Workers
            {
                get { return workers; }
                set { workers = value; }
            }
            public int Number_Enroll
            {
                get { return num_enroll; }
                set { num_enroll = value; }
            }
            public int Number_Dismissed
            {
                get { return num_dismiss; }
                set { num_dismiss = value; }
            }
            public Data(string Com, int Wor, int Enr, int Dis)
            {
                company = Com;
                workers = Wor;
                num_enroll = Enr;
                num_dismiss = Dis;
            }
        }
        public static List<Data> myArr = new List<Data>();
    }
}
