﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace lab3
{
    public partial class Предприятия : Form
    {
        int AddOrChange = 1;
        int ind = -1;
        bool flag_edit = false;
        public Предприятия()
        {
            InitializeComponent();

            dataGridView1.ColumnCount = 4;
            dataGridView1.RowHeadersVisible = false;

            dataGridView1.Columns[0].HeaderText = "Предприятие";
            dataGridView1.Columns[1].HeaderText = "Количество рабочих";
            dataGridView1.Columns[2].HeaderText = "Количество принятых рабочих в текущем месяце";
            dataGridView1.Columns[3].HeaderText = "Количество уволенных рабочих в текущем месяце";

            dataGridView1.AutoResizeColumns();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (AddOrChange == 1)
            {
                if (CompanyTextBox.Text == "" || NumTextBox.Text == "" || EnrTextBox.Text == "" || DisTextBox.Text == "")
                    MessageBox.Show("Одно или несколько полей пустые");
                else
                {
                    string Company = CompanyTextBox.Text;
                    int Num = int.Parse(NumTextBox.Text);
                    int Enr = int.Parse(EnrTextBox.Text);
                    int Dis = int.Parse(DisTextBox.Text);
                    Rab.myArr.Add(new Rab.Data(Company, Num, Enr, Dis));

                    int col = Rab.myArr.Count();
                    dataGridView1.RowCount = col;
                    for (int i = 0; i < col; i++)
                    {
                        dataGridView1.Rows[i].Cells[0].Value = Rab.myArr[i].Company;
                        dataGridView1.Rows[i].Cells[1].Value = Rab.myArr[i].Workers;
                        dataGridView1.Rows[i].Cells[2].Value = Rab.myArr[i].Number_Enroll;
                        dataGridView1.Rows[i].Cells[3].Value = Rab.myArr[i].Number_Dismissed;
                    }

                    AddOrChange = 1;
                    hScrollBar1.Value = 0;
                    hScrollBar2.Value = 0;
                    CompanyTextBox.Text = "";
                    NumTextBox.Text = "";
                    EnrTextBox.Text = "";
                    DisTextBox.Text = "";
                    bool flag_edit = false;
                }
            }
            else
            {
                if (CompanyTextBox.Text == "" || NumTextBox.Text == "" || EnrTextBox.Text == "" || DisTextBox.Text == "")
                    MessageBox.Show("Одно или несколько полей пустые");
                else
                {
                    string Company = CompanyTextBox.Text;
                    int Num = int.Parse(NumTextBox.Text);
                    int Enr = int.Parse(EnrTextBox.Text);
                    int Dis = int.Parse(DisTextBox.Text);
                    Rab.myArr.RemoveAt(ind);
                    Rab.myArr.Insert(ind, new Rab.Data(Company, Num, Enr, Dis));

                    int col = Rab.myArr.Count();
                    dataGridView1.RowCount = col;
                    for (int i = 0; i < col; i++)
                    {
                        dataGridView1.Rows[i].Cells[0].Value = Rab.myArr[i].Company;
                        dataGridView1.Rows[i].Cells[1].Value = Rab.myArr[i].Workers;
                        dataGridView1.Rows[i].Cells[2].Value = Rab.myArr[i].Number_Enroll;
                        dataGridView1.Rows[i].Cells[3].Value = Rab.myArr[i].Number_Dismissed;
                    }

                    AddOrChange = 1;
                    hScrollBar1.Value = 0;
                    hScrollBar2.Value = 0;
                    CompanyTextBox.Text = "";
                    NumTextBox.Text = "";
                    EnrTextBox.Text = "";
                    DisTextBox.Text = "";
                    AddButton.Text = "Добавить";
                    bool flag_edit = false;
                }
            }
        }

        private void dataGridView1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            //DebugBox.Text = e.RowIndex.ToString();
            if (e.RowIndex < 0)
                MessageBox.Show("Вы дважды нажали на заголовок");
            else
            {
                AddButton.Text = "Ок";
                AddOrChange = 2;
                ind = dataGridView1.CurrentRow.Index;
                CompanyTextBox.Text = Rab.myArr[ind].Company;
                NumTextBox.Text = Rab.myArr[ind].Workers.ToString();
                EnrTextBox.Text = Rab.myArr[ind].Number_Enroll.ToString();
                DisTextBox.Text = Rab.myArr[ind].Number_Dismissed.ToString();
                flag_edit = true;
            }
        }

        private void NewWorkersTextBox_TextChanged(object sender, EventArgs e)
        {
            if (EnrTextBox.Text != "")
            {
                bool res = int.TryParse(EnrTextBox.Text, out int r);
                if (res == false)
                {
                    MessageBox.Show("Вы ввели не число");
                    EnrTextBox.Text = EnrTextBox.Text.Substring(0, EnrTextBox.Text.Length - 1);
                }
                else
                {
                    hScrollBar1.Value = r;
                    EnrTextBox.Text = r.ToString();
                }
            }
        }

        private void ReferenceButton_Click(object sender, EventArgs e)
        {
            if (Rab.myArr.Count() == 0)
                MessageBox.Show("Вы не добавили ни одного работника!");
            else
            {
                Справка f = new Справка();
                f.ShowDialog();
            }
        }

        private void hScrollBar1_ValueChanged(object sender, EventArgs e)
        {
            EnrTextBox.Text = hScrollBar1.Value.ToString();
        }

        private void Работники_Load(object sender, EventArgs e)
        {
        }

        private void LastWorkersTextBox_TextChanged(object sender, EventArgs e)
        {
            if (DisTextBox.Text != "")
            {
                bool res = int.TryParse(DisTextBox.Text, out int r);
                if (res == false)
                {
                    MessageBox.Show("Вы ввели не число");
                    DisTextBox.Text = DisTextBox.Text.Substring(0, DisTextBox.Text.Length - 1);
                }
                else
                {
                    hScrollBar2.Value = r;
                    DisTextBox.Text = r.ToString();
                }
            }
        }

        private void hScrollBar2_ValueChanged(object sender, EventArgs e)
        {
            DisTextBox.Text = hScrollBar2.Value.ToString();
        }


        private void WorkersTitleTextBox_TextChanged(object sender, EventArgs e)
        {
            if (NumTextBox.Text != "")
            {
                bool res = int.TryParse(NumTextBox.Text, out int r);
                if (res == false)
                {
                    MessageBox.Show("Вы ввели не число");
                    NumTextBox.Text = NumTextBox.Text.Substring(0, NumTextBox.Text.Length - 1);
                }
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            // Dublicate
            if (flag_edit)
            {
                Rab.myArr.Add(new Rab.Data(Rab.myArr[ind].Company, Rab.myArr[ind].Workers, Rab.myArr[ind].Number_Enroll, Rab.myArr[ind].Number_Dismissed));
                int col = Rab.myArr.Count();
                dataGridView1.RowCount = col;
                for (int i = 0; i < col; i++)
                {
                    dataGridView1.Rows[i].Cells[0].Value = Rab.myArr[i].Company;
                    dataGridView1.Rows[i].Cells[1].Value = Rab.myArr[i].Workers;
                    dataGridView1.Rows[i].Cells[2].Value = Rab.myArr[i].Number_Enroll;
                    dataGridView1.Rows[i].Cells[3].Value = Rab.myArr[i].Number_Dismissed;
                }
                AddOrChange = 2;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Delete
            if (flag_edit)
            {
                Rab.myArr.RemoveAt(ind);
                int col = Rab.myArr.Count();
                dataGridView1.RowCount = col;
                for (int i = 0; i < col; i++)
                {
                    dataGridView1.Rows[i].Cells[0].Value = Rab.myArr[i].Company;
                    dataGridView1.Rows[i].Cells[1].Value = Rab.myArr[i].Workers;
                    dataGridView1.Rows[i].Cells[2].Value = Rab.myArr[i].Number_Enroll;
                    dataGridView1.Rows[i].Cells[3].Value = Rab.myArr[i].Number_Dismissed;
                }
                AddOrChange = 1;
                hScrollBar1.Value = 0;
                hScrollBar2.Value = 0;
                CompanyTextBox.Text = "";
                NumTextBox.Text = "";
                EnrTextBox.Text = "";
                DisTextBox.Text = "";
                AddButton.Text = "Добавить";
            }
        }
    }
}
