﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lab3
{
    public partial class Справка : Form
    {
        public Справка()
        {
            InitializeComponent();

            dataGridView1.ColumnCount = 2;
            dataGridView1.RowHeadersVisible = false;

            dataGridView1.Columns[0].HeaderText = "Предприятие";
            dataGridView1.Columns[1].HeaderText = "Количество рабочих на начало нового месяца";
            
            dataGridView1.AutoResizeColumns();

            int col = Rab.myArr.Count();
            dataGridView1.RowCount = col;
            for (int i = 0; i < col; i++)
            {
                dataGridView1.Rows[i].Cells[0].Value = Rab.myArr[i].Company;
                dataGridView1.Rows[i].Cells[1].Value = (Convert.ToInt32(Rab.myArr[i].Workers) + Convert.ToInt32(Rab.myArr[i].Number_Enroll) - Convert.ToInt32(Rab.myArr[i].Number_Dismissed)).ToString();
            }
        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
            int ind = dataGridView1.CurrentRow.Index;
            CompanyTextBox.Text = Rab.myArr[ind].Company;
            NumTextBox.Text = (Convert.ToInt32(Rab.myArr[ind].Workers) + Convert.ToInt32(Rab.myArr[ind].Number_Enroll) - Convert.ToInt32(Rab.myArr[ind].Number_Dismissed)).ToString();
        }

        private void Справка_Load(object sender, EventArgs e)
        {

        }
    }
}
